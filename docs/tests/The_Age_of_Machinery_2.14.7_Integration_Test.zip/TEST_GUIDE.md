# 2.14.7 — Short Create+ integration check

**Ownership passed — 28 October 2026.** The user confirmed ownership works and approved moving on to 2.15. Restart/continued-progress results from this particular fixture were not reported; do not mark them as passed. Reward advancement/claims were accepted separately in 2.14.6. The remaining steps below are reference checks, not a requirement to repeat accepted work. Reuse the accepted 2.14.5 machine tests and 2.14.6 advancement/reward test. This fixture checks the remaining basic single-player integration: ownership, a world restart and continued progress. It is not campaign content.

## Setup

Create a fresh creative world with cheats and enable `The_Age_of_Machinery_2.14.7_Integration_Test.zip` in world creation's Data Packs screen. Place a Press over a Depot and a Mixer over a Basin yourself. Each arrangement is **machine, one air block, Depot/Basin**. Run both at 32 RPM or more.

The recipes are normal Create+ recipes: **Iron Ingot → Iron Sheet**, and **Andesite + Iron Nugget → Andesite Alloy** (unheated). You need only **3 Iron Ingots, 2 Andesite and 2 Iron Nuggets** for all tests. Feed one recipe at a time.

Check `/tamruntime player`: the active quest must be **Integration Check**, with both objectives at **0/2**.

## 1. Ownership

Replace `X Y Z` below with the **Press block's coordinates**:

```mcfunction
/tamowner remove X Y Z
```

Press one Iron Ingot. A sheet should be produced, but `/tamruntime player` must still show **0/2** sheets. Restore ownership:

```mcfunction
/tamowner register X Y Z
```

Press a second Iron Ingot and mix one Andesite + Iron Nugget. Progress should now be **1/2 sheets and 1/2 alloy**. Collect both outputs.

## 2. Restart

Use **Save and Quit**, then rejoin the same world. Run `/tamruntime player`: both counters must still be **1/2**. Collecting existing outputs or waiting must not add progress.

Press the last Iron Ingot and mix the remaining Andesite + Iron Nugget. Both counters should become **2/2**. You should still have an active quest until you advance it yourself.

## 3. Finish and claim

```mcfunction
/tamruntime advance
/tamruntime claim quest theageofmachinery:integration_test_2147 main_xp
/tamruntime claim quest theageofmachinery:integration_test_2147 main_iron
/tamruntime claim quest theageofmachinery:integration_test_2147 bonus_mixing
```

Expect **10 XP points, 1 Iron Ingot and another 5 XP points**. Repeat any one claim: it must refuse a duplicate.

**Pass:** the unregistered Press gave no credit; registered machines progressed; both counters survived the world restart and continued correctly; earned rewards were delivered once. Report which numbered check failed if something differs.

This confirms basic single-player integration only. Two simultaneous players, crash timing, high throughput and fault injection remain separate open checks in `FUTURE_CORRECTIONS.md`. Final campaign design remains deferred until the mod systems are complete. Do not repeat accepted machine tests or fill large counters.
