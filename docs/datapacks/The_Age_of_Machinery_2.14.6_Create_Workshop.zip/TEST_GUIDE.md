# 2.14.6 — Provisional campaign-system fixture

**Passed — 28 October 2026:** the user confirmed Water Wheel progress, manual advancement and earned reward claims. No further tests are required for this acceptance. **The campaign design is not approved:** finish the mod systems first, then redesign progression from the beginning for the full Create+ inventory. The default opening has incorrect prerequisites; the chapter below is only a system fixture.

Six survival quests follow the unchanged two-quest prelude: **water power, pressing, milling, mixing, brass, crushing**. They use normal Create+ recipes, ingredient quantities, optional challenges and XP/item rewards. No Structure Void or test recipes are included.

## Completed acceptance procedure (reference only)

1. Run `gradlew.bat runClient`. Create a **fresh creative world with cheats** and enable `The_Age_of_Machinery_2.14.6_Create_Workshop.zip` in world creation's Data Packs screen. Keep the previous test world unchanged.
2. Skip only the already-tested prelude:

```mcfunction
/tamruntime progress gather_cobblestone 16
/tamruntime advance
/tamruntime progress craft_crafting_table 1
/tamruntime advance
/tamruntime player
```

3. The active quest should be **A Workshop in Motion**. Craft one Water Wheel (8 planks + 1 Shaft), place it yourself and run it using flowing water. Optional: craft one Cogwheel (1 Shaft + 1 plank) before advancing. Creative inventory can supply the ingredients.
4. Run `/tamruntime player`. Both mandatory objectives should be complete. Run `/tamruntime advance`; **The First Sheets** should become active.
5. Claim the first chapter's earned rewards:

```mcfunction
/tamruntime claim quest theageofmachinery:workshop_water_power main_xp
/tamruntime claim quest theageofmachinery:workshop_water_power main_alloy
```

Expect 40 XP points and 2 Andesite Alloy. Repeating either claim should be refused. If you completed the optional Cogwheel, `/tamruntime claim quest theageofmachinery:workshop_water_power bonus_craft_cogwheel` grants 10 XP points; otherwise that bonus is unavailable.

**Pass:** the new quest loads, real actions complete it, manual advancement selects the next quest, and earned rewards can be claimed once. No full survival playthrough or repeat of the 2.14.5 machine-hook tests is required for this check.

## Remaining provisional fixture content (not required for acceptance)

| Quest | Main goal | Optional challenge |
|---|---|---|
| The First Sheets | Craft Press + Depot; press 1 Iron Sheet | Press 1 Golden Sheet |
| A Working Mill | Craft Millstone; mill Wheat into Flour | Mill 1 Bone Meal into 2 White Dye |
| Working Together | Craft Whisk + Mixer + Basin; mix 1 Andesite + 1 Iron Nugget | Mix Flour + 1000 mB Water into Dough |
| A Hotter Workshop | Craft Empty Blaze Burner, capture/fuel a Blaze, mix Copper + Zinc into 2 Brass | Press 1 Brass Sheet |
| Built for Tougher Work | Craft first batch of 3 Mechanical Crafters; build/run Wheels and crush 1 Cobblestone into Gravel | Crush Gravel into Sand |

Craft objectives count only while their quest is active. For basin work arrange **machine, one air block, Basin**. Run the Mixer at 32 RPM or higher. The full Crushing Wheel recipe uses 21 Mechanical Crafters; its recipe consumes 16 Andesite Alloy, 4 planks and 1 stone to make a pair. Existing infrastructure may be reused.

Ingredient lists are authored in JSON; their journal display is planned for the UI milestone. Only mandatory objectives gate manual advancement. Finish optional challenges before advancing to earn their bonuses. Rewards stay claimable after later transitions.

## Verification

Build, Java parser/domain regressions (mandatory gates, manual completion and optional rewards), schema/recipe checks and null analysis passed in the implementation session. The user confirmed the short in-world system test as passed. Final campaign design remains deferred until the mod systems are complete; 2.14.7 can verify systems with provisional fixtures without approving this campaign or requiring its full playthrough.
